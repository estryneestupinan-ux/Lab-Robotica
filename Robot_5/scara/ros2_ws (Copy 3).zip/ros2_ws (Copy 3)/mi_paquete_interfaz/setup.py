from setuptools import find_packages, setup

package_name = 'mi_paquete_interfaz'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='anonimus',
    maintainer_email='anonimus@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
   entry_points={
        'console_scripts': [
            'abrir_scara = mi_paquete_interfaz.Robotica:main',
            'puente_serial = mi_paquete_interfaz.puente_robot_real:main'
        ],
    },
)
