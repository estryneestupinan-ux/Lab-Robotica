#!/usr/bin/env python3
"""
CONTROL CINEMÁTICO — ROBOT SCARA 3-DOF
Universidad Militar Nueva Granada — Robótica 2026-1

Lanzar con UN solo comando:
    python3 ~/Desktop/Robotica.py

Requiere que Gazebo + controladores ya estén corriendo:
    ros2 launch ~/Desktop/scara_magico.launch.py
"""
import threading, time
import numpy as np
import tkinter as tk
from tkinter import ttk, messagebox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration


# ═══════════════════════════════════════════════════════════════════════════
#  PARÁMETROS DEL ROBOT
# ═══════════════════════════════════════════════════════════════════════════
L1   = 161.0    # mm — eslabón 1
L2   = 112.0    # mm — eslabón 2
ZOFF =  79.0    # mm — offset vertical

PUNTOS = {
    'P0 — Recogida':  np.array([150.0,  100.0, 120.0]),
    'P1 — Entrega 1': np.array([200.0,   50.0,  80.0]),
    'P2 — Entrega 2': np.array([-80.0,  200.0, 100.0]),
    'P3 — Entrega 3': np.array([100.0, -150.0,  90.0]),
}
NOMBRES = list(PUNTOS.keys())

TRAYECTORIAS_DEF = [
    ('P0 — Recogida', 'P1 — Entrega 1'),
    ('P0 — Recogida', 'P2 — Entrega 2'),
    ('P0 — Recogida', 'P3 — Entrega 3'),
]

# ═══════════════════════════════════════════════════════════════════════════
#  TRAYECTORIAS PREDEFINIDAS DEL INFORME (puntos exactos del PDF)
# ═══════════════════════════════════════════════════════════════════════════
# Cada trayectoria define: nombre, P_inicio, P_fin, T_total, T_aceleracion
# Los puntos son los del informe: P0=(180,80,120), P1=(230,60,85), etc.
TRAY_PDF = {
    'T1': {
        'nombre':  'T1 — P₀ → P₁  (entrega delantera-derecha)',
        'color':   '#f97316',   # naranja
        'P0':      np.array([180.0,   80.0, 120.0]),
        'Pf':      np.array([230.0,   60.0,  85.0]),
        'T':       2.5,
        'ta':      0.5,
        # puntos de referencia del informe para validación visual
        'waypoints': [
            (0.0,   np.array([-10.688,  89.468, 41.000])),
            (0.5,   np.array([-11.057,  86.475, 36.653])),
            (1.25,  np.array([-11.322,  76.441, 23.506])),
            (2.0,   np.array([-10.199,  64.543, 10.376])),
            (2.5,   np.array([ -9.457,  59.968,  5.973])),
        ],
        'error_max': 0.0507,
        'detJ_min':  4.76,
    },
    'T2': {
        'nombre':  'T2 — P₀ → P₂  (caja trasera-izquierda)',
        'color':   '#38bdf8',   # celeste
        'P0':      np.array([ 180.0,   80.0, 120.0]),
        'Pf':      np.array([ -50.0,  230.0,  95.0]),
        'T':       2.5,
        'ta':      0.5,
        'waypoints': [
            (0.0,   np.array([-10.688,   89.468, 41.000])),
            (0.5,   np.array([ -4.648,   99.283, 37.895])),
            (1.25,  np.array([ 27.495,  106.527, 28.504])),
            (2.0,   np.array([ 64.503,   79.512, 19.126])),
            (2.5,   np.array([ 77.501,   61.914, 15.981])),
        ],
        'error_max': 0.2365,
        'detJ_min':  4.85,
    },
    'T3': {
        'nombre':  'T3 — P₀ → P₃  (caja delantera-izquierda)',
        'color':   '#4ade80',   # verde
        'P0':      np.array([180.0,   80.0, 120.0]),
        'Pf':      np.array([130.0, -150.0,  90.0]),
        'T':       2.5,
        'ta':      0.5,
        'waypoints': [
            (0.0,   np.array([-10.688,  89.468, 41.000])),
            (0.5,   np.array([-21.133,  98.974, 37.274])),
            (1.25,  np.array([-53.699, 111.546, 26.005])),
            (2.0,   np.array([-79.123,  98.342, 14.751])),
            (2.5,   np.array([-83.465,  88.471, 10.977])),
        ],
        'error_max': 0.2089,
        'detJ_min':  5.11,
    },
}

C = {
    'bg':      '#0f1117',
    'panel':   '#1a1d27',
    'borde':   '#2e3347',
    'naranja': '#f97316',
    'celeste': '#38bdf8',
    'verde':   '#4ade80',
    'rojo':    '#f87171',
    'texto':   '#e2e8f0',
    'gris':    '#94a3b8',
    'amarillo':'#fbbf24',
}


# ═══════════════════════════════════════════════════════════════════════════
#  CINEMÁTICA
# ═══════════════════════════════════════════════════════════════════════════
def fk(q):
    r1  = np.deg2rad(q[0])
    r12 = np.deg2rad(q[0] + q[1])
    return np.array([
        L1*np.cos(r1) + L2*np.cos(r12),
        L1*np.sin(r1) + L2*np.sin(r12),
        q[2] + ZOFF,
    ])

def jacobiano(q):
    r1  = np.deg2rad(q[0])
    r12 = np.deg2rad(q[0] + q[1])
    f   = np.pi / 180.0
    return np.array([
        [(-L1*np.sin(r1)  - L2*np.sin(r12))*f, (-L2*np.sin(r12))*f, 0.0],
        [( L1*np.cos(r1)  + L2*np.cos(r12))*f, ( L2*np.cos(r12))*f, 0.0],
        [0.0, 0.0, 1.0],
    ])

def ik(x, y, z):
    c2 = np.clip((x**2 + y**2 - L1**2 - L2**2) / (2*L1*L2), -1.0, 1.0)
    s2 = np.sqrt(max(1.0 - c2**2, 0.0))
    q2 = np.rad2deg(np.arctan2(s2, c2))
    q1 = np.rad2deg(np.arctan2(y, x) - np.arctan2(L2*s2, L1 + L2*c2))
    return np.array([q1, q2, z - ZOFF])

def trapez(t, T, ta):
    vc = 1.0 / (T - ta);  a = vc / ta
    if   t <= ta:      return 0.5*a*t**2,              a*t
    elif t <= T - ta:  return 0.5*a*ta**2 + vc*(t-ta), vc
    else:
        tau = T - t;   return 1.0 - 0.5*a*tau**2,      a*tau


# ═══════════════════════════════════════════════════════════════════════════
#  NODO ROS 2
# ═══════════════════════════════════════════════════════════════════════════
class ScaraNode(Node):
    def __init__(self):
        super().__init__('scara_control_cinematico')
        self.pub_js = self.create_publisher(JointState,
                          'joint_states', 10)
        self.pub_tj = self.create_publisher(JointTrajectory,
                          '/arm_controller/joint_trajectory', 10)

    def publicar(self, q1r, q2r, d3m):
        js = JointState()
        js.header.stamp = self.get_clock().now().to_msg()
        js.name     = ['Join_1', 'Joint_2', 'Joint_3']
        js.position = [float(q1r), float(q2r), -float(d3m)]
        self.pub_js.publish(js)

        tj = JointTrajectory()
        tj.joint_names = ['Join_1', 'Joint_2', 'Joint_3']
        pt = JointTrajectoryPoint()
        pt.positions       = [float(q1r), float(q2r), -float(d3m)]
        pt.time_from_start = Duration(sec=0, nanosec=200_000_000)
        tj.points.append(pt)
        self.pub_tj.publish(tj)


# ═══════════════════════════════════════════════════════════════════════════
#  INTERFAZ GRÁFICA
# ═══════════════════════════════════════════════════════════════════════════
class App:
    def __init__(self, root, node: ScaraNode):
        self.root      = root
        self.node      = node
        self.corriendo = False
        self.hist      = []

        root.title("Control Cinemático — SCARA 3-DOF  |  UMNG 2026-1")
        root.geometry("1320x840")
        root.minsize(1100, 720)
        root.configure(bg=C['bg'])

        # ─── HEADER ──────────────────────────────────────────────────────
        hdr = tk.Frame(root, bg=C['panel'],
                       highlightbackground=C['borde'], highlightthickness=1)
        hdr.pack(fill='x', padx=10, pady=(10, 0))

        tk.Label(hdr,
                 text="⬡  CONTROL CINEMÁTICO — JACOBIANO INVERSO",
                 font=('Consolas', 14, 'bold'),
                 fg=C['naranja'], bg=C['panel']).pack(side='left',
                                                       padx=16, pady=10)
        tk.Label(hdr,
                 text="L₁=161 mm  ·  L₂=112 mm  ·  Zoff=79 mm  "
                      "·  K=diag(2,2,2) s⁻¹  ·  Perfil trapezoidal",
                 font=('Consolas', 9),
                 fg=C['gris'], bg=C['panel']).pack(side='right', padx=16)

        # ─── CUERPO ───────────────────────────────────────────────────────
        body = tk.Frame(root, bg=C['bg'])
        body.pack(fill='both', expand=True, padx=10, pady=8)

        left = tk.Frame(body, bg=C['bg'], width=440)
        left.pack(side='left', fill='y')
        left.pack_propagate(False)

        right = tk.Frame(body, bg=C['panel'],
                         highlightbackground=C['borde'], highlightthickness=1)
        right.pack(side='left', fill='both', expand=True, padx=(8, 0))

        # ─── 01 TRAYECTORIAS ─────────────────────────────────────────────
        self._sec(left, "01  TRAYECTORIAS", C['celeste'])
        card1 = self._card(left)
        self.filas = []
        for i, (o, d) in enumerate(TRAYECTORIAS_DEF):
            self.filas.append(self._fila(card1, i, o, d))

        # ─── 02 PARÁMETROS ────────────────────────────────────────────────
        self._sec(left, "02  PARÁMETROS DE CONTROL", C['celeste'])
        card2 = self._card(left)
        card2.columnconfigure(1, weight=1)

        self.vT   = tk.DoubleVar(value=2.5)
        self.vTa  = tk.DoubleVar(value=0.5)
        self.vK   = tk.DoubleVar(value=2.0)
        self.vDt  = tk.DoubleVar(value=0.005)
        self.vRet = tk.BooleanVar(value=True)

        for i, (lbl, var, mn, mx) in enumerate([
            ("T total (s)",         self.vT,  0.5,  5.0 ),
            ("T aceleración (s)",   self.vTa, 0.1,  1.5 ),
            ("Ganancia K  (s⁻¹)",  self.vK,  0.5,  10.0),
            ("Paso dt  (s)",        self.vDt, 0.001,0.02),
        ]):
            self._par(card2, i, lbl, var, mn, mx)

        tk.Checkbutton(card2,
                       text="Ejecutar retorno automático a P₀",
                       variable=self.vRet,
                       bg=C['panel'], fg=C['texto'],
                       selectcolor=C['bg'],
                       activebackground=C['panel'],
                       font=('Consolas', 9)).grid(
                           row=8, column=0, columnspan=3,
                           padx=10, pady=(4, 8), sticky='w')

        # ─── 03 TRAYECTORIAS PREDEFINIDAS DEL INFORME ────────────────────
        self._sec(left, "03  TRAYECTORIAS DEL INFORME  (puntos exactos)", C['amarillo'])
        card_pdf = self._card(left)

        # encabezado de la tabla de referencia
        hf = tk.Frame(card_pdf, bg=C['panel'])
        hf.pack(fill='x', padx=8, pady=(6, 2))
        for txt, w in [('', 4), ('Tray.', 6), ('e_max', 8),
                       ('det(J)_min', 10), ('Dur.', 6)]:
            tk.Label(hf, text=txt if txt else '', width=w,
                     font=('Consolas', 8), fg=C['gris'],
                     bg=C['panel']).pack(side='left')
        tk.Label(hf, text='Tray.',     width=6,  font=('Consolas', 8, 'bold'),
                 fg=C['gris'], bg=C['panel']).pack(side='left')
        tk.Label(hf, text='|e|_max',   width=9,  font=('Consolas', 8, 'bold'),
                 fg=C['gris'], bg=C['panel']).pack(side='left')
        tk.Label(hf, text='det(J)_min',width=11, font=('Consolas', 8, 'bold'),
                 fg=C['gris'], bg=C['panel']).pack(side='left')
        tk.Label(hf, text='T(s)',      width=5,  font=('Consolas', 8, 'bold'),
                 fg=C['gris'], bg=C['panel']).pack(side='left')

        self.btns_pdf = {}
        for key, cfg in TRAY_PDF.items():
            rf = tk.Frame(card_pdf, bg=C['panel'])
            rf.pack(fill='x', padx=8, pady=3)

            # indicador de color
            tk.Frame(rf, bg=cfg['color'], width=6,
                     height=22).pack(side='left', padx=(0, 6))

            # botón de ejecución
            btn = tk.Button(rf,
                text=f"▶ {key}",
                command=lambda k=key: self._ejecutar_tray_pdf(k),
                font=('Consolas', 9, 'bold'),
                fg='#0f1117', bg=cfg['color'],
                activebackground=cfg['color'],
                activeforeground='#0f1117',
                relief='flat', cursor='hand2',
                width=6, pady=3)
            btn.pack(side='left', padx=(0, 6))
            self.btns_pdf[key] = btn

            # info de la trayectoria
            tk.Label(rf,
                text=(f"{cfg['nombre'].split('—')[1].strip()[:26]:<26}"
                      f"  |e|≤{cfg['error_max']:.4f}mm"
                      f"  J≥{cfg['detJ_min']:.2f}"
                      f"  {cfg['T']:.1f}s"),
                font=('Consolas', 8), fg=C['gris'],
                bg=C['panel']).pack(side='left')

        # botón "Ejecutar T1+T2+T3 en secuencia"
        tk.Button(card_pdf,
            text="▶▶  EJECUTAR SECUENCIA COMPLETA  T1 → T2 → T3",
            command=self._ejecutar_secuencia_pdf,
            font=('Consolas', 9, 'bold'),
            fg='#0f1117', bg=C['amarillo'],
            activebackground='#d97706',
            relief='flat', cursor='hand2', pady=7
        ).pack(fill='x', padx=8, pady=(6, 10))

        # ─── 04 TELEMETRÍA ────────────────────────────────────────────────
        self._sec(left, "04  TELEMETRÍA EN TIEMPO REAL", C['celeste'])
        card3 = self._card(left)

        self.lbl_est = tk.Label(card3, text="●  EN ESPERA",
                                font=('Consolas', 10, 'bold'),
                                fg=C['gris'], bg=C['panel'])
        self.lbl_est.pack(anchor='w', padx=12, pady=(8, 2))

        self.barra = ttk.Progressbar(card3, length=400, mode='determinate')
        self.barra.pack(fill='x', padx=12, pady=(2, 4))

        self.lbl_seg = tk.Label(card3, text="",
                                font=('Consolas', 8),
                                fg=C['gris'], bg=C['panel'])
        self.lbl_seg.pack(anchor='w', padx=12, pady=(0, 4))

        tg = tk.Frame(card3, bg=C['panel'])
        tg.pack(fill='x', padx=12, pady=(0, 10))
        self.tv = {}
        for i, (campo, u) in enumerate([
            ('q₁','°'),('q₂','°'),('d₃','mm'),('|e|','mm'),
            ('X','mm'),('Y','mm'),('Z','mm'),('det J',''),
        ]):
            r, c = divmod(i, 2); b = c * 4
            tk.Label(tg, text=campo, font=('Consolas', 9), fg=C['gris'],
                     bg=C['panel'], width=5, anchor='e').grid(
                         row=r, column=b, padx=(4, 2), pady=2)
            v = tk.StringVar(value='—');  self.tv[campo] = v
            tk.Label(tg, textvariable=v,
                     font=('Consolas', 9, 'bold'), fg=C['celeste'],
                     bg=C['panel'], width=10, anchor='w').grid(
                         row=r, column=b+1, pady=2)
            tk.Label(tg, text=u, font=('Consolas', 8), fg=C['gris'],
                     bg=C['panel'], width=4).grid(row=r, column=b+2, pady=2)

        # ─── BOTONES ──────────────────────────────────────────────────────
        bf = tk.Frame(left, bg=C['bg'])
        bf.pack(fill='x', pady=(8, 0))

        self.btn_go = tk.Button(bf,
            text="▶   EJECUTAR CONTROL CINEMÁTICO",
            command=self._iniciar,
            font=('Consolas', 11, 'bold'),
            fg='#0f1117', bg=C['naranja'],
            activebackground='#ea6a0a', activeforeground='#0f1117',
            relief='flat', cursor='hand2', pady=13)
        self.btn_go.pack(fill='x', pady=(0, 4))

        tk.Button(bf,
            text="■   DETENER",
            command=self._detener,
            font=('Consolas', 10, 'bold'),
            fg=C['texto'], bg=C['borde'],
            activebackground=C['rojo'], activeforeground='#0f1117',
            relief='flat', cursor='hand2', pady=9).pack(fill='x')

        # ─── PLOT 3D ──────────────────────────────────────────────────────
        self.fig = Figure(figsize=(6.2, 6.2), dpi=100,
                          facecolor=C['panel'])
        self.ax  = self.fig.add_subplot(111, projection='3d')
        self.ax.set_facecolor(C['panel'])

        self.cv3d = FigureCanvasTkAgg(self.fig, master=right)
        self.cv3d.get_tk_widget().pack(fill='both', expand=True,
                                       padx=6, pady=6)
        self._draw([0.0, 90.0, 41.0])

    # ── helpers UI ─────────────────────────────────────────────────────────
    def _sec(self, p, txt, col):
        f = tk.Frame(p, bg=C['bg'])
        f.pack(fill='x', pady=(10, 2))
        tk.Label(f, text=txt, font=('Consolas', 9, 'bold'),
                 fg=col, bg=C['bg']).pack(side='left', padx=2)
        tk.Frame(f, bg=C['borde'], height=1).pack(
            side='left', fill='x', expand=True, padx=6)

    def _card(self, p):
        f = tk.Frame(p, bg=C['panel'],
                     highlightbackground=C['borde'], highlightthickness=1)
        f.pack(fill='x', pady=3, padx=2)
        return f

    def _fila(self, p, idx, o_def, d_def):
        f = tk.Frame(p, bg=C['panel'])
        f.pack(fill='x', padx=8, pady=3)
        tk.Label(f, text=f"T{idx+1}", font=('Consolas', 9, 'bold'),
                 fg=C['naranja'], bg=C['panel'], width=3).pack(side='left')
        vo = tk.StringVar(value=o_def)
        vd = tk.StringVar(value=d_def)
        va = tk.BooleanVar(value=True)
        ttk.Combobox(f, textvariable=vo, values=NOMBRES,
                     width=17, state='readonly',
                     font=('Consolas', 8)).pack(side='left', padx=3)
        tk.Label(f, text='→', fg=C['gris'],
                 bg=C['panel'], font=('Consolas', 10)).pack(side='left')
        ttk.Combobox(f, textvariable=vd, values=NOMBRES,
                     width=17, state='readonly',
                     font=('Consolas', 8)).pack(side='left', padx=3)
        tk.Checkbutton(f, variable=va, bg=C['panel'],
                       selectcolor=C['bg']).pack(side='left', padx=2)
        return {'o': vo, 'd': vd, 'a': va}

    def _par(self, p, idx, lbl, var, mn, mx):
        r = idx * 2
        tk.Label(p, text=lbl, font=('Consolas', 9), fg=C['gris'],
                 bg=C['panel'], anchor='w').grid(
                     row=r, column=0, columnspan=3,
                     padx=10, pady=(6, 0), sticky='w')
        ttk.Scale(p, from_=mn, to=mx, variable=var,
                  orient='horizontal', length=260,
                  command=lambda v, vr=var: vr.set(
                      round(float(v), 4))).grid(
                          row=r+1, column=0, padx=(10, 4), pady=(0, 2))
        tk.Entry(p, textvariable=var, width=7,
                 font=('Consolas', 9), bg=C['bg'], fg=C['texto'],
                 insertbackground=C['texto'],
                 relief='flat').grid(row=r+1, column=1, padx=4)

    # ── telemetría ─────────────────────────────────────────────────────────
    def _telem(self, q, e_norm, det_j, seg=''):
        x = fk(q)
        self.tv['q₁'].set(f"{q[0]:+.2f}")
        self.tv['q₂'].set(f"{q[1]:+.2f}")
        self.tv['d₃'].set(f"{q[2]:+.2f}")
        self.tv['X'].set(f"{x[0]:+.2f}")
        self.tv['Y'].set(f"{x[1]:+.2f}")
        self.tv['Z'].set(f"{x[2]:+.2f}")
        self.tv['|e|'].set(f"{e_norm:.4f}")
        self.tv['det J'].set(f"{det_j:.3f}")
        if seg:
            self.lbl_seg.config(text=f"Segmento activo:  {seg}")

    # ── plot 3D ────────────────────────────────────────────────────────────
    def _draw(self, q, hist=None):
        ax = self.ax;  ax.clear()
        ax.set_facecolor(C['panel'])

        r1  = np.deg2rad(q[0])
        r12 = np.deg2rad(q[0] + q[1])
        p0  = np.array([0.0, 0.0, ZOFF])
        p1  = np.array([L1*np.cos(r1), L1*np.sin(r1), ZOFF])
        p2  = np.array([L1*np.cos(r1)+L2*np.cos(r12),
                         L1*np.sin(r1)+L2*np.sin(r12), ZOFF])
        p3  = np.array([p2[0], p2[1], q[2]+ZOFF])

        ax.plot(*zip(p0,p1), color=C['naranja'], lw=3.5,
                solid_capstyle='round', label='L1')
        ax.plot(*zip(p1,p2), color=C['celeste'], lw=3.5,
                solid_capstyle='round', label='L2')
        ax.plot(*zip(p2,p3), color=C['verde'],   lw=4.0,
                linestyle='--', label='d3')

        for pt, col, sz in [(p0,'#fff',50),(p1,C['naranja'],80),
                             (p2,C['celeste'],80),(p3,C['verde'],110)]:
            ax.scatter(*pt, color=col, s=sz, zorder=6, depthshade=False)

        if hist and len(hist) > 2:
            arr = np.array(hist)
            ax.plot(arr[:,0], arr[:,1], arr[:,2],
                    color=C['naranja'], lw=1.2, alpha=0.4,
                    linestyle=':', label='Recorrido EF')

        for nm, pt in PUNTOS.items():
            ax.scatter(*pt, color='#cbd5e1', s=35, marker='^',
                        alpha=0.55, depthshade=False)
            ax.text(pt[0]+5, pt[1]+5, pt[2], nm[:2],
                    color='#94a3b8', fontsize=7)

        xx, yy = np.meshgrid([-280,280],[-280,280])
        ax.plot_surface(xx, yy, np.full_like(xx, ZOFF),
                        alpha=0.05, color=C['gris'])

        ax.set_xlim(-300,300); ax.set_ylim(-300,300); ax.set_zlim(0,260)
        ax.set_xlabel('X (mm)', color=C['gris'], fontsize=8)
        ax.set_ylabel('Y (mm)', color=C['gris'], fontsize=8)
        ax.set_zlabel('Z (mm)', color=C['gris'], fontsize=8)
        ax.tick_params(colors=C['gris'], labelsize=7)
        for pane in [ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane]:
            pane.fill = False
            pane.set_edgecolor(C['borde'])
        ax.grid(True, color=C['borde'], lw=0.5, alpha=0.4)
        ax.legend(fontsize=7, loc='upper left',
                  facecolor=C['panel'], labelcolor=C['texto'],
                  framealpha=0.6)
        self.cv3d.draw()

    # ── control cinemático ─────────────────────────────────────────────────
    def _iniciar(self):
        if self.corriendo:
            return
        threading.Thread(target=self._loop, daemon=True).start()

    def _detener(self):
        self.corriendo = False
        self.lbl_est.config(text="■  DETENIDO", fg=C['rojo'])
        self.btn_go.config(state='normal')
        # rehabilitar botones del PDF
        for btn in self.btns_pdf.values():
            btn.config(state='normal')

    def _loop(self):
        self.corriendo = True
        self.btn_go.config(state='disabled')
        self.barra['value'] = 0
        self.hist.clear()

        T   = self.vT.get()
        ta  = self.vTa.get()
        K   = np.diag([self.vK.get()] * 3)
        dt  = self.vDt.get()
        ret = self.vRet.get()

        # construir segmentos
        segs = []
        for fila in self.filas:
            if not fila['a'].get():
                continue
            P0 = PUNTOS[fila['o'].get()]
            Pf = PUNTOS[fila['d'].get()]
            n0 = fila['o'].get()[:2]
            nd = fila['d'].get()[:2]
            segs.append((P0, Pf, f"{n0} → {nd}"))
            if ret:
                segs.append((Pf, P0, f"{nd} → {n0}  (retorno)"))

        if not segs:
            messagebox.showwarning("Sin trayectorias",
                                   "Activa al menos una trayectoria.")
            self.corriendo = False
            self.btn_go.config(state='normal')
            return

        self._run_segmentos(segs, T, ta, K, dt)
        self.btn_go.config(state='normal')

    def _run_segmentos(self, segs, T, ta, K, dt):
        """Núcleo de ejecución: recibe lista de (P0, Pf, nombre) y parámetros."""
        N_total = len(segs) * int(T / dt)
        paso    = 0

        for si, (P0, Pf, nombre) in enumerate(segs):
            if not self.corriendo:
                break

            self.lbl_est.config(
                text=f"●  EJECUTANDO  —  {si+1}/{len(segs)}",
                fg=C['verde'])

            q  = ik(*P0)
            N  = int(T / dt)
            dP = Pf - P0

            for k in range(N):
                if not self.corriendo:
                    break

                t      = k * dt
                s, sd  = trapez(t, T, ta)
                xd     = P0 + s * dP
                xd_dot = sd * dP
                x_act  = fk(q)
                e      = xd - x_act
                J      = jacobiano(q)
                det_j  = float(np.linalg.det(J))

                try:
                    qdot = np.linalg.solve(J, xd_dot + K @ e)
                except np.linalg.LinAlgError:
                    qdot = np.linalg.pinv(J) @ (xd_dot + K @ e)

                q = q + qdot * dt

                self.node.publicar(
                    np.deg2rad(q[0]),
                    np.deg2rad(q[1]),
                    q[2] / 1000.0)

                if k % 8 == 0:
                    self.hist.append(fk(q).tolist())
                    self._telem(q, float(np.linalg.norm(e)),
                                det_j, nombre)
                    self._draw(q.copy(), self.hist)
                    self.barra['value'] = min(
                        100, ((paso + k) / N_total) * 100)
                    self.root.update_idletasks()

                time.sleep(dt)

            paso += N

        if self.corriendo:
            self.lbl_est.config(text="✔  COMPLETADO", fg=C['verde'])
            self.barra['value'] = 100
        self.corriendo = False

    # ── trayectorias predefinidas del PDF ──────────────────────────────────
    def _ejecutar_tray_pdf(self, key: str):
        """Ejecuta una trayectoria individual del informe (T1, T2 o T3)."""
        if self.corriendo:
            messagebox.showwarning("Ocupado",
                "Detén la ejecución actual antes de lanzar una nueva.")
            return

        cfg = TRAY_PDF[key]

        def run():
            self.corriendo = True
            self.btn_go.config(state='disabled')
            for b in self.btns_pdf.values():
                b.config(state='disabled')
            self.hist.clear()
            self.barra['value'] = 0

            T  = cfg['T']
            ta = cfg['ta']
            K  = np.diag([self.vK.get()] * 3)   # ganancia del slider
            dt = self.vDt.get()                  # paso del slider

            segs = [(cfg['P0'], cfg['Pf'], cfg['nombre'])]

            # retorno opcional usando el checkbox existente
            if self.vRet.get():
                segs.append((cfg['Pf'], cfg['P0'],
                              f"Retorno  {cfg['nombre'].split('—')[0].strip()}"))

            self._run_segmentos(segs, T, ta, K, dt)

            self.btn_go.config(state='normal')
            for b in self.btns_pdf.values():
                b.config(state='normal')

        threading.Thread(target=run, daemon=True).start()

    def _ejecutar_secuencia_pdf(self):
        """Ejecuta T1 → T2 → T3 en secuencia, con retorno a P0 entre cada una."""
        if self.corriendo:
            messagebox.showwarning("Ocupado",
                "Detén la ejecución actual antes de lanzar una nueva.")
            return

        def run():
            self.corriendo = True
            self.btn_go.config(state='disabled')
            for b in self.btns_pdf.values():
                b.config(state='disabled')
            self.hist.clear()
            self.barra['value'] = 0

            K  = np.diag([self.vK.get()] * 3)
            dt = self.vDt.get()

            # Construir secuencia completa: ida + retorno a P0 para cada Tx
            segs = []
            for key in ('T1', 'T2', 'T3'):
                cfg = TRAY_PDF[key]
                segs.append((cfg['P0'], cfg['Pf'],
                              cfg['nombre']))
                # siempre volver a P0 del informe entre trayectorias
                segs.append((cfg['Pf'], TRAY_PDF['T1']['P0'],
                              f"Retorno → P₀  [{key}]"))

            # usar T y ta del informe (todas son 2.5s / 0.5s)
            self._run_segmentos(segs,
                                T=2.5, ta=0.5, K=K, dt=dt)

            self.btn_go.config(state='normal')
            for b in self.btns_pdf.values():
                b.config(state='normal')

        threading.Thread(target=run, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════
#  MAIN — todo en un solo bloque
# ═══════════════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    # 1. Inicializar ROS 2
    rclpy.init()
    node = ScaraNode()

    # 2. Hilo de spin ROS 2 (no bloquea la GUI)
    threading.Thread(target=lambda: rclpy.spin(node),
                     daemon=True).start()

    # 3. Ventana Tkinter
    root = tk.Tk()
    App(root, node)

    try:
        root.mainloop()
    finally:
        rclpy.shutdown()