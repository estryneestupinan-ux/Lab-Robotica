#!/usr/bin/env python3
"""
CONTROL CINEMÁTICO POR JACOBIANO INVERSO — ROBOT SCARA 3-DOF
Universidad Militar Nueva Granada — Robótica 2026-1

Lanzar con:
    ros2 launch ~/Desktop/scara_magico.launch.py
    (la GUI arranca automáticamente 5 s después de Gazebo)

O manualmente en terminal separada:
    python3 ~/Desktop/scara_control_cinematico.py
"""
import os, sys, time, threading
import numpy as np
import tkinter as tk
from tkinter import ttk, messagebox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration


# ═══════════════════════════════════════════════════════════════════════════
#  PARÁMETROS DEL ROBOT
# ═══════════════════════════════════════════════════════════════════════════
L1   = 161.0   # mm — eslabón 1
L2   = 112.0   # mm — eslabón 2
ZOFF =  79.0   # mm — offset vertical fijo

PUNTOS = {
    'P0 — Recogida':  np.array([150.0,  100.0, 120.0]),
    'P1 — Entrega 1': np.array([200.0,   50.0,  80.0]),
    'P2 — Entrega 2': np.array([-80.0,  200.0, 100.0]),
    'P3 — Entrega 3': np.array([100.0, -150.0,  90.0]),
}
NOMBRES = list(PUNTOS.keys())

TRAYECTORIAS_DEF = [
    ('P0 — Recogida', 'P1 — Entrega 1'),
    ('P0 — Recogida', 'P2 — Entrega 2'),
    ('P0 — Recogida', 'P3 — Entrega 3'),
]

# Paleta oscura
C = {
    'bg':      '#0f1117',
    'panel':   '#1a1d27',
    'borde':   '#2e3347',
    'naranja': '#f97316',
    'celeste': '#38bdf8',
    'verde':   '#4ade80',
    'rojo':    '#f87171',
    'texto':   '#e2e8f0',
    'gris':    '#94a3b8',
}


# ═══════════════════════════════════════════════════════════════════════════
#  CINEMÁTICA
# ═══════════════════════════════════════════════════════════════════════════
def fk(q):
    """q=[q1°, q2°, d3 mm] → [x, y, z] mm"""
    r1  = np.deg2rad(q[0])
    r12 = np.deg2rad(q[0] + q[1])
    return np.array([
        L1*np.cos(r1) + L2*np.cos(r12),
        L1*np.sin(r1) + L2*np.sin(r12),
        q[2] + ZOFF,
    ])


def jacobiano(q):
    """Jacobiano analítico 3×3  [mm/°, mm/°, mm/mm]"""
    r1  = np.deg2rad(q[0])
    r12 = np.deg2rad(q[0] + q[1])
    f   = np.pi / 180.0
    return np.array([
        [(-L1*np.sin(r1)  - L2*np.sin(r12))*f,
         (-L2*np.sin(r12))*f,  0.0],
        [( L1*np.cos(r1)  + L2*np.cos(r12))*f,
         ( L2*np.cos(r12))*f,  0.0],
        [0.0, 0.0, 1.0],
    ])


def ik(x, y, z):
    """Cinemática inversa codo-arriba → [q1°, q2°, d3 mm]"""
    c2  = (x**2 + y**2 - L1**2 - L2**2) / (2*L1*L2)
    c2  = float(np.clip(c2, -1.0, 1.0))
    s2  = np.sqrt(max(1.0 - c2**2, 0.0))
    q2  = np.rad2deg(np.arctan2(s2, c2))
    q1  = np.rad2deg(np.arctan2(y, x)
                     - np.arctan2(L2*s2, L1 + L2*c2))
    d3  = z - ZOFF
    return np.array([q1, q2, d3])


def trapez(t, T, ta):
    """Perfil trapezoidal normalizado → (s, ṡ)"""
    vc = 1.0 / (T - ta)
    a  = vc / ta
    if t <= ta:
        return 0.5*a*t**2, a*t
    elif t <= T - ta:
        return 0.5*a*ta**2 + vc*(t - ta), vc
    else:
        tau = T - t
        return 1.0 - 0.5*a*tau**2, a*tau


# ═══════════════════════════════════════════════════════════════════════════
#  NODO ROS 2
# ═══════════════════════════════════════════════════════════════════════════
class ScaraNode(Node):
    def __init__(self):
        super().__init__('scara_control_cinematico')
        self.pub_state = self.create_publisher(JointState,
                                               'joint_states', 10)
        self.pub_traj  = self.create_publisher(JointTrajectory,
                                               '/arm_controller/joint_trajectory',
                                               10)

    def publicar(self, q1_rad, q2_rad, d3_m):
        # ── JointState ──────────────────────────────────────────────────
        js = JointState()
        js.header.stamp = self.get_clock().now().to_msg()
        js.name     = ['Join_1', 'Joint_2', 'Joint_3']
        js.position = [float(q1_rad), float(q2_rad), -float(d3_m)]
        self.pub_state.publish(js)

        # ── JointTrajectory ──────────────────────────────────────────────
        tj = JointTrajectory()
        tj.joint_names = ['Join_1', 'Joint_2', 'Joint_3']
        pt = JointTrajectoryPoint()
        pt.positions       = [float(q1_rad), float(q2_rad), -float(d3_m)]
        pt.time_from_start = Duration(sec=0, nanosec=200_000_000)
        tj.points.append(pt)
        self.pub_traj.publish(tj)


# ═══════════════════════════════════════════════════════════════════════════
#  INTERFAZ GRÁFICA
# ═══════════════════════════════════════════════════════════════════════════
class GUI:
    def __init__(self, root, node: ScaraNode):
        self.root = root
        self.node = node
        self.corriendo = False
        self.hist_xyz  = []           # historial de posiciones para el plot

        # ── Ventana ──────────────────────────────────────────────────────
        root.title("Control Cinemático — SCARA 3-DOF  |  UMNG Robótica 2026-1")
        root.geometry("1320x840")
        root.minsize(1100, 700)
        root.configure(bg=C['bg'])

        # ── Layout raíz ─────────────────────────────────────────────────
        #   [header]
        #   [left panel] [3-D plot]
        header = tk.Frame(root, bg=C['panel'],
                          highlightbackground=C['borde'],
                          highlightthickness=1)
        header.pack(fill='x', padx=10, pady=(10, 0))

        body = tk.Frame(root, bg=C['bg'])
        body.pack(fill='both', expand=True, padx=10, pady=8)

        left = tk.Frame(body, bg=C['bg'], width=430)
        left.pack(side='left', fill='y')
        left.pack_propagate(False)

        right = tk.Frame(body, bg=C['panel'],
                         highlightbackground=C['borde'],
                         highlightthickness=1)
        right.pack(side='left', fill='both', expand=True, padx=(8, 0))

        # ════════════════════════════════════════════════════════════════
        #  HEADER
        # ════════════════════════════════════════════════════════════════
        tk.Label(header,
                 text="⬡  CONTROL CINEMÁTICO — JACOBIANO INVERSO",
                 font=('Consolas', 14, 'bold'),
                 fg=C['naranja'], bg=C['panel']).pack(
                     side='left', padx=16, pady=10)
        tk.Label(header,
                 text="L₁=161 mm  ·  L₂=112 mm  ·  Z_off=79 mm  "
                      "·  K=diag(2,2,2) s⁻¹  ·  Perfil trapezoidal",
                 font=('Consolas', 9),
                 fg=C['gris'], bg=C['panel']).pack(
                     side='right', padx=16)

        # ════════════════════════════════════════════════════════════════
        #  PANEL 01 — TRAYECTORIAS
        # ════════════════════════════════════════════════════════════════
        self._titulo(left, "01  TRAYECTORIAS", C['celeste'])

        tray_cont = self._card(left)
        self.filas = []
        for idx, (o, d) in enumerate(TRAYECTORIAS_DEF):
            self.filas.append(self._fila_tray(tray_cont, idx, o, d))

        # ════════════════════════════════════════════════════════════════
        #  PANEL 02 — PARÁMETROS
        # ════════════════════════════════════════════════════════════════
        self._titulo(left, "02  PARÁMETROS DE CONTROL", C['celeste'])

        par_cont = self._card(left)
        par_cont.columnconfigure(1, weight=1)

        self.vT   = tk.DoubleVar(value=2.5)
        self.vTa  = tk.DoubleVar(value=0.5)
        self.vK   = tk.DoubleVar(value=2.0)
        self.vDt  = tk.DoubleVar(value=0.005)
        self.vRet = tk.BooleanVar(value=True)

        specs = [
            ("T total (s)",        self.vT,  0.5,  5.0,  0.1  ),
            ("T aceleración (s)",  self.vTa, 0.1,  1.5,  0.05 ),
            ("Ganancia  K  (s⁻¹)", self.vK,  0.5,  10.0, 0.5  ),
            ("Paso  dt  (s)",       self.vDt, 0.001,0.02, 0.001),
        ]
        for i, (lbl, var, mn, mx, res) in enumerate(specs):
            self._param(par_cont, i, lbl, var, mn, mx)

        tk.Checkbutton(par_cont,
                       text="Ejecutar retorno automático a P₀",
                       variable=self.vRet,
                       bg=C['panel'], fg=C['texto'],
                       selectcolor=C['bg'],
                       activebackground=C['panel'],
                       font=('Consolas', 9)).grid(
                           row=len(specs)*2, column=0,
                           columnspan=3, padx=10, pady=(4, 8), sticky='w')

        # ════════════════════════════════════════════════════════════════
        #  PANEL 03 — TELEMETRÍA EN TIEMPO REAL
        # ════════════════════════════════════════════════════════════════
        self._titulo(left, "03  TELEMETRÍA  EN  TIEMPO  REAL", C['celeste'])

        tel_cont = self._card(left)

        self.lbl_estado = tk.Label(tel_cont,
                                   text="●  EN ESPERA",
                                   font=('Consolas', 10, 'bold'),
                                   fg=C['gris'], bg=C['panel'])
        self.lbl_estado.pack(anchor='w', padx=12, pady=(8, 2))

        self.barra = ttk.Progressbar(tel_cont, length=400,
                                     mode='determinate')
        self.barra.pack(fill='x', padx=12, pady=(2, 6))

        self.lbl_tray = tk.Label(tel_cont, text="",
                                 font=('Consolas', 8),
                                 fg=C['gris'], bg=C['panel'])
        self.lbl_tray.pack(anchor='w', padx=12, pady=(0, 4))

        # Grid 4×2 de valores
        grid = tk.Frame(tel_cont, bg=C['panel'])
        grid.pack(fill='x', padx=12, pady=(0, 10))
        self.tv = {}
        campos = [
            ('q₁','°'),('q₂','°'),('d₃','mm'),('|e|','mm'),
            ('X','mm'), ('Y','mm'),('Z','mm'), ('det J',''),
        ]
        for i, (c, u) in enumerate(campos):
            r, col = divmod(i, 2)
            base = col * 4
            tk.Label(grid, text=c,
                     font=('Consolas', 9), fg=C['gris'],
                     bg=C['panel'], width=5,
                     anchor='e').grid(row=r, column=base,
                                      padx=(4, 2), pady=2)
            v = tk.StringVar(value='—')
            self.tv[c] = v
            tk.Label(grid, textvariable=v,
                     font=('Consolas', 9, 'bold'), fg=C['celeste'],
                     bg=C['panel'], width=10,
                     anchor='w').grid(row=r, column=base+1, pady=2)
            tk.Label(grid, text=u,
                     font=('Consolas', 8), fg=C['gris'],
                     bg=C['panel'], width=4).grid(
                         row=r, column=base+2, pady=2)

        # ════════════════════════════════════════════════════════════════
        #  BOTONES
        # ════════════════════════════════════════════════════════════════
        btn_frame = tk.Frame(left, bg=C['bg'])
        btn_frame.pack(fill='x', pady=(6, 0))

        self.btn_go = tk.Button(
            btn_frame,
            text="▶   EJECUTAR CONTROL CINEMÁTICO",
            command=self._iniciar,
            font=('Consolas', 11, 'bold'),
            fg='#0f1117', bg=C['naranja'],
            activebackground='#ea6a0a', activeforeground='#0f1117',
            relief='flat', cursor='hand2', pady=13)
        self.btn_go.pack(fill='x', pady=(0, 4))

        tk.Button(
            btn_frame,
            text="■   DETENER",
            command=self._detener,
            font=('Consolas', 10, 'bold'),
            fg=C['texto'], bg=C['borde'],
            activebackground=C['rojo'], activeforeground='#0f1117',
            relief='flat', cursor='hand2', pady=9).pack(fill='x')

        # ════════════════════════════════════════════════════════════════
        #  PLOT 3-D
        # ════════════════════════════════════════════════════════════════
        self.fig = Figure(figsize=(6.2, 6.2), dpi=100,
                          facecolor=C['panel'])
        self.ax  = self.fig.add_subplot(111, projection='3d')
        self.ax.set_facecolor(C['panel'])

        self.canvas3d = FigureCanvasTkAgg(self.fig, master=right)
        self.canvas3d.get_tk_widget().pack(fill='both', expand=True,
                                           padx=6, pady=6)
        self._dibujar([0.0, 90.0, 41.0])

    # ── Helpers UI ─────────────────────────────────────────────────────────
    def _titulo(self, parent, texto, color):
        f = tk.Frame(parent, bg=C['bg'])
        f.pack(fill='x', pady=(10, 2))
        tk.Label(f, text=texto, font=('Consolas', 9, 'bold'),
                 fg=color, bg=C['bg']).pack(side='left', padx=2)
        tk.Frame(f, bg=C['borde'], height=1).pack(
            side='left', fill='x', expand=True, padx=6)

    def _card(self, parent):
        f = tk.Frame(parent, bg=C['panel'],
                     highlightbackground=C['borde'],
                     highlightthickness=1)
        f.pack(fill='x', pady=3, padx=2)
        return f

    def _fila_tray(self, parent, idx, o_def, d_def):
        f = tk.Frame(parent, bg=C['panel'])
        f.pack(fill='x', padx=8, pady=3)

        tk.Label(f, text=f"T{idx+1}",
                 font=('Consolas', 9, 'bold'),
                 fg=C['naranja'], bg=C['panel'],
                 width=3).pack(side='left')

        vo = tk.StringVar(value=o_def)
        vd = tk.StringVar(value=d_def)
        va = tk.BooleanVar(value=True)

        ttk.Combobox(f, textvariable=vo, values=NOMBRES,
                     width=17, state='readonly',
                     font=('Consolas', 8)).pack(side='left', padx=3)
        tk.Label(f, text='→', fg=C['gris'],
                 bg=C['panel'],
                 font=('Consolas', 10)).pack(side='left')
        ttk.Combobox(f, textvariable=vd, values=NOMBRES,
                     width=17, state='readonly',
                     font=('Consolas', 8)).pack(side='left', padx=3)
        tk.Checkbutton(f, variable=va,
                       bg=C['panel'],
                       selectcolor=C['bg']).pack(side='left', padx=2)
        return {'o': vo, 'd': vd, 'a': va}

    def _param(self, parent, idx, label, var, mn, mx):
        r = idx * 2
        tk.Label(parent, text=label,
                 font=('Consolas', 9), fg=C['gris'],
                 bg=C['panel'], anchor='w').grid(
                     row=r, column=0, columnspan=3,
                     padx=10, pady=(6, 0), sticky='w')
        ttk.Scale(parent, from_=mn, to=mx, variable=var,
                  orient='horizontal', length=250,
                  command=lambda v, vr=var: vr.set(
                      round(float(v), 4))).grid(
                          row=r+1, column=0, padx=(10, 4), pady=(0, 2))
        tk.Entry(parent, textvariable=var, width=7,
                 font=('Consolas', 9),
                 bg=C['bg'], fg=C['texto'],
                 insertbackground=C['texto'],
                 relief='flat').grid(row=r+1, column=1, padx=4)

    # ── Actualizar telemetría ──────────────────────────────────────────────
    def _telem(self, q, e_norm, det_j, nombre=''):
        x = fk(q)
        self.tv['q₁'].set(f"{q[0]:+.2f}")
        self.tv['q₂'].set(f"{q[1]:+.2f}")
        self.tv['d₃'].set(f"{q[2]:+.2f}")
        self.tv['X'].set(f"{x[0]:+.2f}")
        self.tv['Y'].set(f"{x[1]:+.2f}")
        self.tv['Z'].set(f"{x[2]:+.2f}")
        self.tv['|e|'].set(f"{e_norm:.4f}")
        self.tv['det J'].set(f"{det_j:.3f}")
        if nombre:
            self.lbl_tray.config(text=f"Trayectoria activa:  {nombre}")

    # ── Plot 3-D ──────────────────────────────────────────────────────────
    def _dibujar(self, q, hist=None):
        ax = self.ax
        ax.clear()
        ax.set_facecolor(C['panel'])

        r1  = np.deg2rad(q[0])
        r12 = np.deg2rad(q[0] + q[1])

        p0 = np.array([0.0,               0.0,               ZOFF         ])
        p1 = np.array([L1*np.cos(r1),     L1*np.sin(r1),     ZOFF         ])
        p2 = np.array([L1*np.cos(r1)+L2*np.cos(r12),
                        L1*np.sin(r1)+L2*np.sin(r12), ZOFF               ])
        p3 = np.array([p2[0], p2[1], q[2] + ZOFF])

        # Eslabones
        ax.plot(*zip(p0, p1), color=C['naranja'], lw=3.5,
                solid_capstyle='round', label='L1')
        ax.plot(*zip(p1, p2), color=C['celeste'], lw=3.5,
                solid_capstyle='round', label='L2')
        ax.plot(*zip(p2, p3), color=C['verde'],   lw=4.0,
                linestyle='--', solid_capstyle='round', label='d3')

        # Juntas
        for pt, col, sz in [
            (p0, '#ffffff', 50),
            (p1, C['naranja'], 80),
            (p2, C['celeste'], 80),
            (p3, C['verde'],  110),
        ]:
            ax.scatter(*pt, color=col, s=sz, zorder=6, depthshade=False)

        # Trayectoria histórica del efector final
        if hist and len(hist) > 2:
            arr = np.array(hist)
            ax.plot(arr[:, 0], arr[:, 1], arr[:, 2],
                    color=C['naranja'], lw=1.2, alpha=0.45,
                    linestyle=':', label='Recorrido EF')

        # Puntos de tarea
        for nombre, pt in PUNTOS.items():
            ax.scatter(*pt, color='#cbd5e1', s=35,
                        marker='^', alpha=0.55, depthshade=False)
            ax.text(pt[0]+5, pt[1]+5, pt[2], nombre[:2],
                    color='#94a3b8', fontsize=7)

        # Plano de trabajo (semitransparente)
        xx, yy = np.meshgrid([-280, 280], [-280, 280])
        ax.plot_surface(xx, yy, np.full_like(xx, ZOFF),
                        alpha=0.06, color=C['gris'])

        ax.set_xlim(-300, 300)
        ax.set_ylim(-300, 300)
        ax.set_zlim(0, 260)
        ax.set_xlabel('X (mm)', color=C['gris'], fontsize=8)
        ax.set_ylabel('Y (mm)', color=C['gris'], fontsize=8)
        ax.set_zlabel('Z (mm)', color=C['gris'], fontsize=8)
        ax.tick_params(colors=C['gris'], labelsize=7)
        ax.xaxis.pane.fill = False
        ax.yaxis.pane.fill = False
        ax.zaxis.pane.fill = False
        ax.xaxis.pane.set_edgecolor(C['borde'])
        ax.yaxis.pane.set_edgecolor(C['borde'])
        ax.zaxis.pane.set_edgecolor(C['borde'])
        ax.grid(True, color=C['borde'], lw=0.5, alpha=0.4)
        ax.legend(fontsize=7, loc='upper left',
                  facecolor=C['panel'], labelcolor=C['texto'],
                  framealpha=0.6)

        self.canvas3d.draw()

    # ── Control cinemático ─────────────────────────────────────────────────
    def _iniciar(self):
        if self.corriendo:
            return
        threading.Thread(target=self._loop, daemon=True).start()

    def _detener(self):
        self.corriendo = False
        self.lbl_estado.config(text="■  DETENIDO", fg=C['rojo'])
        self.btn_go.config(state='normal')

    def _loop(self):
        self.corriendo = True
        self.btn_go.config(state='disabled')
        self.barra['value'] = 0
        self.hist_xyz.clear()

        T   = self.vT.get()
        ta  = self.vTa.get()
        K   = np.diag([self.vK.get()] * 3)
        dt  = self.vDt.get()
        ret = self.vRet.get()

        # Construir lista de segmentos
        segmentos = []
        for fila in self.filas:
            if not fila['a'].get():
                continue
            P0 = PUNTOS[fila['o'].get()]
            Pf = PUNTOS[fila['d'].get()]
            segmentos.append((P0, Pf,
                               f"{fila['o'].get()[:2]} → {fila['d'].get()[:2]}"))
            if ret:
                segmentos.append((Pf, P0,
                                   f"{fila['d'].get()[:2]} → {fila['o'].get()[:2]}  (retorno)"))

        if not segmentos:
            messagebox.showwarning("Sin trayectorias",
                                   "Activa al menos una trayectoria.")
            self.corriendo = False
            self.btn_go.config(state='normal')
            return

        N_total = len(segmentos) * int(T / dt)
        paso    = 0

        for seg_idx, (P0, Pf, nombre) in enumerate(segmentos):
            if not self.corriendo:
                break

            self.lbl_estado.config(
                text=f"●  EJECUTANDO  —  seg {seg_idx+1}/{len(segmentos)}",
                fg=C['verde'])

            q  = ik(*P0)
            N  = int(T / dt)
            dP = Pf - P0

            for k in range(N):
                if not self.corriendo:
                    break

                t = k * dt
                s, sd   = trapez(t, T, ta)
                xd      = P0 + s * dP
                xd_dot  = sd * dP
                x_act   = fk(q)
                e       = xd - x_act
                J       = jacobiano(q)
                det_j   = float(np.linalg.det(J))

                try:
                    qdot = np.linalg.solve(J, xd_dot + K @ e)
                except np.linalg.LinAlgError:
                    qdot = np.linalg.pinv(J) @ (xd_dot + K @ e)

                q = q + qdot * dt

                # ── Publicar en ROS 2 ────────────────────────────────
                self.node.publicar(
                    np.deg2rad(q[0]),
                    np.deg2rad(q[1]),
                    q[2] / 1000.0)

                # ── Actualizar UI cada 8 pasos ────────────────────────
                if k % 8 == 0:
                    e_norm = float(np.linalg.norm(e))
                    self.hist_xyz.append(fk(q).tolist())
                    self._telem(q, e_norm, det_j, nombre)
                    self._dibujar(q.copy(), self.hist_xyz)
                    paso_pct = min(100, ((paso + k) / N_total) * 100)
                    self.barra['value'] = paso_pct
                    self.root.update_idletasks()

                time.sleep(dt)

            paso += N

        # ── Fin ──────────────────────────────────────────────────────────
        if self.corriendo:
            self.lbl_estado.config(text="✔  COMPLETADO", fg=C['verde'])
            self.barra['value'] = 100
        self.corriendo = False
        self.btn_go.config(state='normal')


# ═══════════════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════════════
def main():
    rclpy.init()
    node = ScaraNode()

    # Hilo ROS 2
    threading.Thread(target=lambda: rclpy.spin(node),
                     daemon=True).start()

    root = tk.Tk()
    GUI(root, node)

    try:
        root.mainloop()
    finally:
        rclpy.shutdown()


if __name__ == '__main__':
    main()