import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import serial
import math

class PuenteSerialRobot(Node):
    def __init__(self):
        super().__init__('puente_serial_robot')
        
        # --- CONFIGURACIÓN SERIAL ---
        # Asegúrate de que coincida con el puerto de tu ESP32
        self.puerto_serie = '/dev/ttyUSB0' 
        self.baudios = 115200
        
        try:
            # timeout=0.01 es para que ROS no se quede "congelado" esperando al ESP32
            self.arduino = serial.Serial(self.puerto_serie, self.baudios, timeout=0.01)
            self.get_logger().info(f'--- CONECTADO AL ESP32 EN {self.puerto_serie} ---')
        except Exception as e:
            self.get_logger().error(f'ERROR: No se pudo conectar al ESP32. ¿Permisos dados? {e}')

        # --- SUSCRIPCIÓN AL TRAZADO ---
        # Escuchamos el tópico donde publicas las posiciones (usualmente /joint_states)
        self.sub = self.create_subscription(
            JointState,
            '/joint_states',
            self.listener_callback,
            10)

    def listener_callback(self, msg):
        try:
            # 1. Convertimos de Radianes a Grados para el ESP32
            pos_j1 = math.degrees(msg.position[0])
            pos_j2 = math.degrees(msg.position[1])
            pos_j3 = math.degrees(msg.position[2])

            # 2. Formatear el mensaje: "45.00,90.00,10.00\n"
            cadena_mando = f"{pos_j1:.2f},{pos_j2:.2f},{pos_j3:.2f}\n"

            # 3. Enviar por el cable USB a la velocidad del rayo
            if hasattr(self, 'arduino') and self.arduino.is_open:
                self.arduino.write(cadena_mando.encode('utf-8'))
                
                # Descomenta la siguiente línea solo para ver qué estás enviando (hace ruido en la terminal)
                # self.get_logger().info(f'Enviado al ESP32: {cadena_mando.strip()}')

        except IndexError:
            self.get_logger().warn('Esperando recibir la posición de las 3 articulaciones...')
        except Exception as e:
            self.get_logger().error(f'Error al procesar/enviar datos: {e}')

def main(args=None):
    rclpy.init(args=args)
    nodo = PuenteSerialRobot()
    rclpy.spin(nodo)
    nodo.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()