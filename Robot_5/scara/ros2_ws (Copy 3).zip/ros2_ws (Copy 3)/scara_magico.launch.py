import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (IncludeLaunchDescription, RegisterEventHandler,
                             TimerAction, ExecuteProcess)
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def generate_launch_description():

    # ── Rutas ────────────────────────────────────────────────────────────
    urdf_file = os.path.expanduser(
        '~/Desktop/Robotica/ros2_ws/src/modelo_robot/urdf/'
        'Ensamble_Robot_Scara.urdf')
    world_path = os.path.expanduser(
        '~/Desktop/Robotica/ros2_ws/src/modelo_robot/worlds/'
        'scara_entorno.world')
    controllers_yaml = os.path.expanduser(
        '~/Desktop/Robotica/ros2_ws/src/modelo_robot/config/'
        'scara_controllers.yaml')

    # GUI — mismo directorio que este launch file
    gui_script = os.path.expanduser(
        '~/Desktop/Robotica.py')

    with open(urdf_file, 'r') as f:
        robot_desc = f.read()

    # ── Nodos ────────────────────────────────────────────────────────────
    rsp_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_desc}]
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([os.path.join(
            get_package_share_directory('ros_gz_sim'),
            'launch', 'gz_sim.launch.py')]),
        launch_arguments={
            'gz_args': f'-v 4 -r {world_path}',
            'on_exit_shutdown': 'True'
        }.items(),
    )

    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=['-topic', 'robot_description',
                   '-name', 'Robot_Scara_F', '-z', '0.01'],
        output='screen'
    )

    controller_manager = Node(
        package='controller_manager',
        executable='ros2_control_node',
        parameters=[
            {'robot_description': robot_desc},
            controllers_yaml
        ],
        output='screen'
    )

    spawn_broadcaster = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster'],
        output='screen'
    )

    spawn_arm = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['arm_controller'],
        output='screen'
    )

    # ── Encadenamiento de controladores ──────────────────────────────────
    delay_broadcaster = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=spawn_entity,
            on_exit=[spawn_broadcaster],
        )
    )

    delay_arm = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=spawn_broadcaster,
            on_exit=[spawn_arm],
        )
    )

    # ── GUI — arranca 5 s después para que los controladores estén listos ─
    gui = TimerAction(
        period=5.0,
        actions=[
            ExecuteProcess(
                cmd=['python3', gui_script],
                output='screen'
            )
        ]
    )

    return LaunchDescription([
        rsp_node,
        gazebo,
        spawn_entity,
        controller_manager,
        delay_broadcaster,
        delay_arm,
        gui,
    ])