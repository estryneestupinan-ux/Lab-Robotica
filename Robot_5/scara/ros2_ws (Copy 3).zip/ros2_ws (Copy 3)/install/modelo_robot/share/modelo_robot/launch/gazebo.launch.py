import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    package_name = 'modelo_robot'
    
    # TRUCO: Apuntamos directo a tu carpeta 'src' para que nunca se pierda
    # (Si en el Paso 1 viste que tu archivo se llama diferente, cámbialo aquí al final)
    urdf_file = os.path.expanduser('~/ros2_ws/src/modelo_robot/urdf/Ensamble_Robot_Scara.urdf')
    
    with open(urdf_file, 'r') as infp:
        robot_desc = infp.read()

    rsp_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_desc}]
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([os.path.join(
            get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')]),
    )

    spawn_entity = Node(
        package='gazebo_ros', 
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', '-entity', 'Robot_Scara_F'],
        output='screen'
    )

    return LaunchDescription([
        rsp_node,
        gazebo,
        spawn_entity,
    ])
