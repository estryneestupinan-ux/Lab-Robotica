import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
import math
import threading

class ScaraIKNode(Node):
    def __init__(self):
        super().__init__('scara_ik_node')
        
        # ¡AQUÍ ESTÁ LA MAGIA! El topic correcto descubierto en tu lista
        self.publisher_ = self.create_publisher(JointTrajectory, '/arm_controller/joint_trajectory', 10)
        
        # Parámetros del robot en metros
        self.L1 = 0.112
        self.L2 = 0.161
        self.Z_BASE = 0.366
        
        # ⚠️ IMPORTANTE: Nombres de las articulaciones. 
        # Tienen que ser EXACTAMENTE los nombres que están en tu URDF.
        # (Si se llaman diferente, cámbialos aquí)
        self.joint_names = ['Join_1', 'Joint_2', 'Joint_3'] 
        
        self.thread = threading.Thread(target=self.terminal_loop)
        self.thread.start()

    def terminal_loop(self):
        print("\n=== CEREBRO CINEMÁTICO SCARA ACTIVADO (MODO TRAYECTORIA) ===")
        print(f"Alcance: {self.L1 + self.L2:.3f} m máx | {abs(self.L1 - self.L2):.3f} m min")
        
        while rclpy.ok():
            try:
                print("\nIngresa las coordenadas objetivo (en metros):")
                x = float(input("X (ej. 0.200): "))
                y = float(input("Y (ej. 0.150): "))
                z = float(input("Z (ej. 0.416): "))
                
                self.calcular_y_mover(x, y, z)
                
            except ValueError:
                print("Por favor, ingresa solo números.")

    def calcular_y_mover(self, x, y, z):
        r_cuadrado = x**2 + y**2
        r = math.sqrt(r_cuadrado)
        
        if r > (self.L1 + self.L2) or r < abs(self.L1 - self.L2):
            print("❌ ERROR: El punto está fuera del alcance del brazo.")
            return

        cos_theta2 = (r_cuadrado - self.L1**2 - self.L2**2) / (2 * self.L1 * self.L2)
        cos_theta2 = max(min(cos_theta2, 1.0), -1.0) 
        theta2 = math.acos(cos_theta2) 
        
        beta = math.atan2(y, x)
        gamma = math.atan2(self.L2 * math.sin(theta2), self.L1 + self.L2 * math.cos(theta2))
        theta1 = beta - gamma
        
        d3_ext = z - self.Z_BASE
        d3_comando = -d3_ext if d3_ext > 0 else d3_ext 

        print(f"✅ Ángulos calculados: T1={math.degrees(theta1):.1f}°, T2={math.degrees(theta2):.1f}°, d3={d3_comando*1000:.1f}mm")
        
        # Construir el mensaje de trayectoria
        msg = JointTrajectory()
        msg.joint_names = self.joint_names
        
        # Crear un "punto" en la trayectoria
        point = JointTrajectoryPoint()
        point.positions = [theta1, theta2, d3_comando]
        
        # Decirle que se tome 1.5 segundos en llegar suavemente
        point.time_from_start.sec = 1 
        point.time_from_start.nanosec = 500000000 
        
        msg.points.append(point)
        
        # ¡Enviar a Gazebo!
        self.publisher_.publish(msg)
        print("🤖 Enviando trayectoria a Gazebo...")

def main(args=None):
    rclpy.init(args=args)
    node = ScaraIKNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
